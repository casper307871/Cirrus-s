# Cirrus Bot AWS Integration Package

This package helps connect the Cirrus bot to AWS services (e.g., S3).

## Setup

1. Create and activate a virtual environment:
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate   # Linux/macOS
   .venv\Scripts\activate      # Windows
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Configure AWS credentials (one-time setup):
   ```bash
   aws configure
   ```

4. Test the connection:
   ```bash
   python aws_test.py
   ```

## Notes
- Replace `your-bucket-name` in `aws_test.py` with your actual S3 bucket name.
- This package currently includes S3 test integration. You can expand it for DynamoDB, RDS, or other AWS services as needed.
