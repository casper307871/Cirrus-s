import boto3

def test_s3_connection():
    """Simple S3 test to confirm AWS credentials work."""
    s3 = boto3.resource("s3")
    print("✅ Connected to AWS S3")

    print("Listing buckets:")
    for bucket in s3.buckets.all():
        print(" -", bucket.name)

    # Optional: upload a test file
    with open("cirrus_test.txt", "w") as f:
        f.write("Hello from Cirrus bot!")

    with open("cirrus_test.txt", "rb") as data:
        bucket_name = "your-bucket-name"  # change this!
        s3.Bucket(bucket_name).put_object(Key="cirrus_test.txt", Body=data)
        print(f"✅ Uploaded cirrus_test.txt to {bucket_name}")

if __name__ == "__main__":
    test_s3_connection()
